# social_media_app
a social media app looks like instagrame 
containe 4 sections  profile page , signin page , signup page , home page with a signup system
with this app we can post some pics with caption and add likes for other users also a follow and unfollow feature and all of this using python (framework django) 
